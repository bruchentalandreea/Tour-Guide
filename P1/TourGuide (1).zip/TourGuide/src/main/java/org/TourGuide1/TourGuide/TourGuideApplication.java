package org.TourGuide1.TourGuide;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TourGuideApplication {

	public static void main(String[] args) {
		SpringApplication.run(TourGuideApplication.class, args);
	}

}
